
shape_spawn_type = "polygon"

draw_aabb = False

positional_correction = True

debug_intersections = False
iterations = 5
