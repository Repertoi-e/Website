
mouse_line = False
mouse_start, mouse, mouse_last = None, None, None

grabbed = None
grabbed_offset = None
grabbed_was_static = False
